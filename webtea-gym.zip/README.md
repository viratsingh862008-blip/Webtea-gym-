# Webtea Gym — Website

A single-page, conversion-focused website for a local gym, built with
semantic HTML5, plain CSS3 (custom properties + BEM), and vanilla
JavaScript (ES6+), per the project's PRD, Architecture, Design, and
Rules documents.

## Running locally

No build step required.

```bash
npx serve .
```

Then open the printed local URL. Opening `index.html` directly in a
browser also works, **except** form submission, which needs a server
(Netlify Forms only activates on a real Netlify deploy).

## What's a placeholder right now

This is a development build. Before going live, replace:

| Item | Where | Current placeholder |
|---|---|---|
| Map coordinates | `index.html` (`#find-us` + footer iframes, "Get Directions" links, JSON-LD `geo`) | `26.1234,84.5678` |
| Address | `index.html` (`#find-us`), JSON-LD | "MG Road, Near City Center, Your City, Bihar 800001" |
| Phone number | All `tel:` links, JSON-LD | `+91 98765 43210` |
| Email | `mailto:` link, JSON-LD | `info@webteagym.com` |
| Logo | Inline SVG in navbar/hero (`index.html`) | Text-based "WEBTEA GYM" mark |
| Hero video | `assets/videos/hero-loop.mp4` (missing — poster image shows instead) | Unsplash fallback photo |
| Sub-hero videos | `assets/videos/trainer-spotlight.mp4`, `member-transformation.mp4` | Not present — click-to-play will 404 until added |
| Gallery/moments/testimonial photos | Various `<img>` tags | Unsplash stock photos |
| Testimonial video | `#testimonials` iframe | Placeholder YouTube embed |
| GA4 Measurement ID | `js/analytics.js` | `G-XXXXXXXXXX` |
| Owner photo | `#owner-contact` | Unsplash stock photo |

To get your map coordinates: open your gym's Google Maps share link on
a phone or PC, look at the address bar/app URL for a segment like
`@26.1234,84.5678`, and use those two numbers as `LATITUDE,LONGITUDE`
in the places listed above.

## Video assets

Videos are referenced but not bundled (this environment can't generate
video files). Each `<video>`/play button already has the right
markup and a poster image, so the page works today — add real MP4s at
the paths above (H.264, ideally under 2MB for the hero loop; trim with
`ffmpeg -i input.mp4 -c:v libx264 -crf 28 -an output.mp4`) and no code
changes are needed.

## Deployment

- **Hosting:** Netlify or Vercel (static).
- **Forms:** Both forms already have `data-netlify="true"` and a
  honeypot field. On Netlify, no backend code is needed — submissions
  arrive by email/dashboard automatically.
- **Analytics:** Add the GA4 snippet with your real Measurement ID in
  `<head>`, and set `GA_MEASUREMENT_ID` in `js/analytics.js`.

## File structure

```
webtea-gym/
├── index.html
├── css/
│   └── styles.css
├── js/
│   ├── main.js          (entry point — initializes all modules)
│   ├── navigation.js    (sticky nav, mobile menu, active-link tracking)
│   ├── videoPlayer.js   (hero sound toggle, sub-hero click-to-play)
│   ├── carousel.js      (Swiper init + lightbox)
│   ├── accordion.js     (FAQ expand/collapse)
│   ├── formHandler.js   (validation + Netlify Forms submission)
│   └── analytics.js     (GA4 event tracking)
├── assets/
│   ├── images/          (empty — see placeholder table above)
│   └── videos/          (empty — see placeholder table above)
├── favicon.ico
└── README.md
```

## Notes

- Membership pricing (Basic ₹500 / Moderate ₹700 / Advanced ₹1200) and
  trainer profile ("Ravi") reflect the latest project brief and
  supersede earlier PRD tier names (Basic/Pro/Elite).
- A dedicated `#trainer` section was added beyond the original 13-section
  sitemap to host Ravi's full profile, per the brief's request for a
  complete trainer bio.
