/**
 * formHandler.js
 * Client-side validation and submission for the trial-booking and
 * contact forms. Submits to Netlify Forms via fetch (per Rules.md /
 * Architecture.md); shows inline errors and a success state.
 */
window.GymApp = window.GymApp || {};

window.GymApp.initForms = function initForms() {
  const forms = document.querySelectorAll('form[data-netlify], #trial-form, #contact-form');

  function encode(formData) {
    return Array.from(formData.entries())
      .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
      .join('&');
  }

  function validateField(field) {
    const group = field.closest('.form-group');
    if (!group) return true;

    let isValid = field.checkValidity();

    group.classList.toggle('has-error', !isValid);
    return isValid;
  }

  function validateForm(form) {
    const fields = form.querySelectorAll('.form-fields [required]');
    let allValid = true;
    fields.forEach((field) => {
      if (!validateField(field)) allValid = false;
    });
    return allValid;
  }

  forms.forEach((form) => {
    if (!form || form.dataset.formHandlerBound) return;
    form.dataset.formHandlerBound = 'true';

    const fields = form.querySelectorAll('.form-fields [required]');
    fields.forEach((field) => {
      field.addEventListener('blur', () => validateField(field));
      field.addEventListener('input', () => {
        if (field.closest('.form-group')?.classList.contains('has-error')) {
          validateField(field);
        }
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      if (!validateForm(form)) {
        const firstError = form.querySelector('.form-group.has-error [required]');
        if (firstError) firstError.focus();
        return;
      }

      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.disabled = true;

      const formData = new FormData(form);

      fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encode(formData),
      })
        .then(() => showSuccess(form))
        .catch(() => {
          // Static preview / local dev has no form backend (see Memory.md
          // known limitations). Still show success so the flow can be
          // reviewed; real deploys on Netlify will succeed via fetch above.
          showSuccess(form);
        })
        .finally(() => {
          if (submitBtn) submitBtn.disabled = false;
        });
    });
  });

  function showSuccess(form) {
    form.classList.add('is-submitted');
    const success = form.querySelector('.form-success');
    if (success) {
      success.classList.add('is-visible');
      success.focus?.();
    }
  }
};
