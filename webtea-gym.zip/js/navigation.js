/**
 * navigation.js
 * Sticky header behavior: mobile menu toggle, focus trap, and
 * scroll-based active-link highlighting via IntersectionObserver.
 */
window.GymApp = window.GymApp || {};

window.GymApp.initNavigation = function initNavigation() {
  const toggle = document.querySelector('.navbar__toggle');
  const mobileNav = document.getElementById('mobile-nav');
  const body = document.body;

  if (toggle && mobileNav) {
    const focusableSelector = 'a[href], button:not([disabled])';

    function openMenu() {
      body.classList.add('nav-open');
      toggle.setAttribute('aria-expanded', 'true');
      toggle.setAttribute('aria-label', 'Close menu');
      const first = mobileNav.querySelector(focusableSelector);
      if (first) first.focus();
    }

    function closeMenu() {
      body.classList.remove('nav-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Open menu');
    }

    toggle.addEventListener('click', () => {
      if (body.classList.contains('nav-open')) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    mobileNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', closeMenu);
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && body.classList.contains('nav-open')) {
        closeMenu();
        toggle.focus();
      }
    });

    // Basic focus trap while menu is open
    mobileNav.addEventListener('keydown', (e) => {
      if (e.key !== 'Tab' || !body.classList.contains('nav-open')) return;
      const focusables = Array.from(mobileNav.querySelectorAll(focusableSelector));
      if (!focusables.length) return;
      const firstEl = focusables[0];
      const lastEl = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === firstEl) {
        e.preventDefault();
        lastEl.focus();
      } else if (!e.shiftKey && document.activeElement === lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    });
  }

  // Active link highlighting on scroll
  const sections = Array.from(document.querySelectorAll('main section[id]'));
  const navLinks = Array.from(document.querySelectorAll('.navbar__link'));

  if ('IntersectionObserver' in window && sections.length && navLinks.length) {
    const setActive = (id) => {
      navLinks.forEach((link) => {
        const isMatch = link.getAttribute('href') === `#${id}`;
        link.classList.toggle('is-active', isMatch);
        if (isMatch) {
          link.setAttribute('aria-current', 'page');
        } else {
          link.removeAttribute('aria-current');
        }
      });
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(entry.target.id);
          }
        });
      },
      { rootMargin: '-40% 0px -55% 0px', threshold: 0 }
    );

    sections.forEach((section) => observer.observe(section));
  }
};
