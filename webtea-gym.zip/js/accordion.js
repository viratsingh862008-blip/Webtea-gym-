/**
 * accordion.js
 * FAQ accordion: click toggles aria-expanded and reveals the answer panel.
 * Only one item is open at a time.
 */
window.GymApp = window.GymApp || {};

window.GymApp.initAccordions = function initAccordions() {
  const items = document.querySelectorAll('.faq-item');
  if (!items.length) return;

  function closeItem(item) {
    const question = item.querySelector('.faq-item__question');
    const answer = item.querySelector('.faq-item__answer');
    item.setAttribute('data-open', 'false');
    question.setAttribute('aria-expanded', 'false');
    answer.style.maxHeight = null;
  }

  function openItem(item) {
    const question = item.querySelector('.faq-item__question');
    const answer = item.querySelector('.faq-item__answer');
    item.setAttribute('data-open', 'true');
    question.setAttribute('aria-expanded', 'true');
    answer.style.maxHeight = `${answer.scrollHeight}px`;
  }

  items.forEach((item) => {
    const question = item.querySelector('.faq-item__question');
    if (!question) return;

    question.addEventListener('click', () => {
      const isOpen = item.getAttribute('data-open') === 'true';

      items.forEach((other) => {
        if (other !== item) closeItem(other);
      });

      if (isOpen) {
        closeItem(item);
      } else {
        openItem(item);
      }
    });
  });

  // Keep open answer's max-height correct on resize (fluid type can reflow height)
  window.addEventListener('resize', () => {
    items.forEach((item) => {
      if (item.getAttribute('data-open') === 'true') {
        const answer = item.querySelector('.faq-item__answer');
        answer.style.maxHeight = `${answer.scrollHeight}px`;
      }
    });
  });
};
