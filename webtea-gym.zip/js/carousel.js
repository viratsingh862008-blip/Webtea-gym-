/**
 * carousel.js
 * Initializes Swiper instances for the credibility gallery and the
 * moments carousel, plus a lightweight lightbox for gallery images
 * and the "See All Amenities" CTA.
 */
window.GymApp = window.GymApp || {};

window.GymApp.initCarousels = function initCarousels() {
  if (typeof Swiper === 'undefined') return;

  const gallerySwiperEl = document.querySelector('[data-gallery-swiper]');
  const momentsSwiperEl = document.querySelector('[data-moments-swiper]');

  let gallerySwiper = null;

  if (gallerySwiperEl) {
    gallerySwiper = new Swiper(gallerySwiperEl, {
      slidesPerView: 1.2,
      spaceBetween: 16,
      loop: true,
      a11y: { enabled: true },
      keyboard: { enabled: true },
      pagination: { el: gallerySwiperEl.querySelector('.swiper-pagination'), clickable: true },
      navigation: {
        nextEl: gallerySwiperEl.querySelector('.swiper-button-next'),
        prevEl: gallerySwiperEl.querySelector('.swiper-button-prev'),
      },
      breakpoints: {
        576: { slidesPerView: 2 },
        992: { slidesPerView: 3 },
      },
    });
  }

  if (momentsSwiperEl) {
    // eslint-disable-next-line no-new
    new Swiper(momentsSwiperEl, {
      slidesPerView: 1.4,
      spaceBetween: 14,
      loop: true,
      autoplay: { delay: 4000, disableOnInteraction: true },
      a11y: { enabled: true },
      keyboard: { enabled: true },
      pagination: { el: momentsSwiperEl.querySelector('.swiper-pagination'), clickable: true },
      breakpoints: {
        576: { slidesPerView: 2.2 },
        768: { slidesPerView: 3 },
        992: { slidesPerView: 4 },
      },
    });
  }

  // Lightbox
  const lightbox = document.querySelector('[data-lightbox]');
  const lightboxImg = document.querySelector('[data-lightbox-img]');
  const lightboxClose = document.querySelector('[data-lightbox-close]');
  const seeAllBtn = document.querySelector('[data-open-gallery]');
  let lastFocused = null;

  function openLightbox(src, alt) {
    if (!lightbox || !lightboxImg) return;
    lastFocused = document.activeElement;
    lightboxImg.src = src;
    lightboxImg.alt = alt || '';
    lightbox.classList.add('is-open');
    lightbox.setAttribute('aria-hidden', 'false');
    lightboxClose.focus();
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    if (!lightbox) return;
    lightbox.classList.remove('is-open');
    lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (lastFocused) lastFocused.focus();
  }

  if (lightboxClose) {
    lightboxClose.addEventListener('click', closeLightbox);
  }

  if (lightbox) {
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) closeLightbox();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && lightbox.classList.contains('is-open')) closeLightbox();
    });
  }

  // Clicking any gallery image opens the lightbox
  document.querySelectorAll('.gallery-swiper img').forEach((img) => {
    img.style.cursor = 'zoom-in';
    img.addEventListener('click', () => openLightbox(img.src, img.alt));
  });

  // "See All Amenities" opens the first gallery image as an entry point
  if (seeAllBtn) {
    seeAllBtn.addEventListener('click', () => {
      const firstImg = document.querySelector('.gallery-swiper img');
      if (firstImg) openLightbox(firstImg.src, firstImg.alt);
      document.getElementById('credibility')?.scrollIntoView({ behavior: 'smooth' });
    });
  }
};
