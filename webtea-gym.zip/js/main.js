/**
 * main.js
 * Entry point. Initializes all feature modules once the DOM is ready.
 * (analytics.js initializes itself since it loads async — see that file.)
 */
document.addEventListener('DOMContentLoaded', function () {
  var app = window.GymApp || {};

  if (typeof app.initNavigation === 'function') app.initNavigation();
  if (typeof app.initVideoPlayers === 'function') app.initVideoPlayers();
  if (typeof app.initCarousels === 'function') app.initCarousels();
  if (typeof app.initAccordions === 'function') app.initAccordions();
  if (typeof app.initForms === 'function') app.initForms();
  if (typeof app.initAnalytics === 'function') app.initAnalytics();
});
