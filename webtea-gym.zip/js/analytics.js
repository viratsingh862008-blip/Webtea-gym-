/**
 * analytics.js
 * Lightweight GA4 event tracking. Loaded async (per Rules.md) and
 * safe to run before or after gtag.js is available.
 *
 * Replace GA_MEASUREMENT_ID with the real Measurement ID at deploy time.
 */
(function () {
  var GA_MEASUREMENT_ID = 'G-XXXXXXXXXX'; // placeholder — set at deploy time

  function trackEvent(eventName, params) {
    if (typeof window.gtag === 'function') {
      window.gtag('event', eventName, params || {});
    }
  }

  function bindClickTracking() {
    document.querySelectorAll('[data-analytics]').forEach(function (el) {
      if (el.dataset.analyticsBound) return;
      el.dataset.analyticsBound = 'true';

      el.addEventListener('click', function () {
        trackEvent(el.getAttribute('data-analytics'), {
          location: el.getAttribute('data-analytics-location') || 'unspecified',
          label: (el.textContent || '').trim().slice(0, 60),
        });
      });
    });
  }

  function bindPlanSelection() {
    document.querySelectorAll('[data-choose-plan]').forEach(function (btn) {
      if (btn.dataset.analyticsBound) return;
      btn.dataset.analyticsBound = 'true';

      btn.addEventListener('click', function () {
        trackEvent('choose_plan', { plan: btn.getAttribute('data-choose-plan') });
        document.getElementById('trial-form-wrapper')?.scrollIntoView({ behavior: 'smooth' });
      });
    });
  }

  window.GymApp = window.GymApp || {};
  window.GymApp.initAnalytics = function initAnalytics() {
    bindClickTracking();
    bindPlanSelection();
  };

  // analytics.js loads async and may run before main.js's DOMContentLoaded
  // listener, so initialize immediately if the DOM is already parsed.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', window.GymApp.initAnalytics);
  } else {
    window.GymApp.initAnalytics();
  }
})();
