/**
 * videoPlayer.js
 * Hero mute/unmute toggle, and sub-hero cards that swap their poster
 * image for an inline playing <video> on click (no autoplay, per Rules.md).
 */
window.GymApp = window.GymApp || {};

window.GymApp.initVideoPlayers = function initVideoPlayers() {
  // Hero sound toggle
  const heroVideo = document.querySelector('.hero__media');
  const soundToggle = document.querySelector('[data-hero-sound-toggle]');

  if (heroVideo && soundToggle) {
    soundToggle.addEventListener('click', () => {
      heroVideo.muted = !heroVideo.muted;
      const isMuted = heroVideo.muted;
      soundToggle.setAttribute('aria-pressed', String(!isMuted));
      soundToggle.setAttribute('aria-label', isMuted ? 'Unmute hero video' : 'Mute hero video');
    });
  }

  // Sub-hero click-to-play video cards
  const videoCards = document.querySelectorAll('[data-video-card]');

  videoCards.forEach((card) => {
    const playBtn = card.querySelector('.video-card__play');
    if (!playBtn) return;

    playBtn.addEventListener('click', () => {
      const src = playBtn.getAttribute('data-video-src');
      const poster = playBtn.getAttribute('data-video-poster');
      if (!src) return;

      const video = document.createElement('video');
      video.className = 'video-card__media';
      video.controls = true;
      video.playsInline = true;
      video.preload = 'metadata';
      if (poster) video.poster = poster;

      const source = document.createElement('source');
      source.src = src;
      source.type = 'video/mp4';
      video.appendChild(source);

      card.insertBefore(video, card.firstChild);
      card.classList.add('is-playing');

      video.play().catch(() => {
        // Autoplay-with-sound can be blocked; controls remain visible so the
        // user can start playback manually.
      });
    });
  });
};
